# M.Tbank Android Demo

A native Android Studio project for a fictional M.Tbank banking prototype.

## Included screens
- Login
- Home/dashboard
- Accounts
- Account details
- Transfers (review-only, no money movement)
- Cards
- Profile
- Notifications
- Transaction history
- Sign out

## Demo credentials
Username: demo@mtbank.example
Password: Demo123!

## Important
This app is intentionally demo-only. It has no real banking integration, payment processing, credential storage, or real customer data.

## Build
Open the project folder in Android Studio and let Gradle sync. Then run the `app` configuration on an emulator or Android device.
