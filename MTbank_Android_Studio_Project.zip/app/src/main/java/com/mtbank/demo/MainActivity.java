package com.mtbank.demo;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(11,59,120), BLUE=Color.rgb(18,100,183), BG=Color.rgb(245,248,252);
    LinearLayout root, content;
    TextView title;
    EditText user, pass;
    boolean logged=false;

    String[] tx = {"Harbor Coffee  •  Sep 27, 2026     -$8.75",
                   "Demo Direct Deposit  •  Sep 26, 2026     +$2,500.00",
                   "Market Place  •  Sep 25, 2026     -$64.20",
                   "Electric Utility  •  Sep 23, 2026     -$118.40",
                   "Demo Transfer  •  Sep 21, 2026     +$450.00"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); showLogin();
    }

    TextView tv(String s,int sp,int color){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setPadding(0,6,0,6); return v;
    }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    Button btn(String text, View.OnClickListener l){
        Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(bg(BLUE,18)); b.setOnClickListener(l);
        b.setPadding(16,8,16,8); return b;
    }
    LinearLayout box(){
        LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setPadding(20,18,20,18);
        x.setBackground(bg(Color.WHITE,28)); return x;
    }
    void base(boolean withNav){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        if(withNav){
            LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(18,12,18,10);
            bar.setBackgroundColor(Color.WHITE);
            TextView brand=tv("M.Tbank",22,NAVY); brand.setTypeface(null,1);
            bar.addView(brand,new LinearLayout.LayoutParams(0,60,1));
            Button out=new Button(this); out.setText("Sign out"); out.setAllCaps(false); out.setOnClickListener(v->{logged=false;showLogin();});
            bar.addView(out,new LinearLayout.LayoutParams(110,55));
            root.addView(bar);
        }
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,16,18,90);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        if(withNav) addNav();
    }
    void addNav(){
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        String[] names={"Home","Accounts","Transfers","Cards","Profile"};
        for(String n:names){ Button b=new Button(this); b.setText(n); b.setTextSize(11); b.setAllCaps(false);
            b.setOnClickListener(v->{ if(n.equals("Home"))home(); else if(n.equals("Accounts"))accounts(); else if(n.equals("Transfers"))transfers(); else if(n.equals("Cards"))cards(); else profile();});
            nav.addView(b,new LinearLayout.LayoutParams(0,62,1)); }
        root.addView(nav);
    }
    void showLogin(){
        base(false);
        content.setPadding(28,55,28,25);
        TextView logo=tv("M.Tbank",38,NAVY); logo.setTypeface(null,1); content.addView(logo);
        TextView tag=tv("YOUR TRUST. OUR PRIORITY.",11,BLUE); tag.setPadding(2,0,0,34); content.addView(tag);
        TextView w=tv("Welcome Back",34,NAVY); w.setTypeface(null,1); content.addView(w);
        content.addView(tv("Sign in to your M.Tbank demo account.",17,Color.DKGRAY));
        user=new EditText(this); user.setHint("Username or Email Address"); user.setSingleLine(); user.setPadding(18,8,18,8); content.addView(user,new LinearLayout.LayoutParams(-1,65));
        pass=new EditText(this); pass.setHint("Password"); pass.setInputType(0x81); pass.setSingleLine(); pass.setPadding(18,8,18,8); content.addView(pass,new LinearLayout.LayoutParams(-1,65));
        TextView hint=tv("Demo credentials: demo@mtbank.example  /  Demo123!",12,Color.GRAY); content.addView(hint);
        Button sign=btn("Sign In   →",v->login()); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,62); sp.setMargins(0,18,0,8); content.addView(sign,sp);
        Button bio=new Button(this); bio.setText("Use Biometric Demo"); bio.setAllCaps(false); bio.setOnClickListener(v->{user.setText("demo@mtbank.example");pass.setText("Demo123!");login();}); content.addView(bio);
        TextView note=tv("DEMO ONLY — fictional data. No real banking credentials or transactions.",11,Color.GRAY); note.setGravity(Gravity.CENTER); note.setPadding(0,35,0,0); content.addView(note);
    }
    void login(){
        if("demo@mtbank.example".contentEquals(user.getText()) && "Demo123!".contentEquals(pass.getText())){
            logged=true; home();
        } else Toast.makeText(this,"Use the demo credentials shown on this screen.",Toast.LENGTH_LONG).show();
    }
    void heading(String s,String sub){
        TextView h=tv(s,28,NAVY); h.setTypeface(null,1); content.addView(h);
        if(sub!=null) content.addView(tv(sub,14,Color.DKGRAY));
    }
    void home(){
        base(true); heading("Good evening, Alex 👋","M.Tbank Demo • fictional account");
        LinearLayout bal=box(); bal.setBackground(bg(NAVY,26));
        TextView a=tv("TOTAL AVAILABLE BALANCE",12,Color.WHITE); a.setAlpha(.8f); bal.addView(a);
        TextView amount=tv("$24,680.42",36,Color.WHITE); amount.setTypeface(null,1); bal.addView(amount);
        TextView ac=tv("Everyday Checking  •••• 4821",13,Color.WHITE); ac.setAlpha(.8f); bal.addView(ac);
        content.addView(bal);
        TextView quick=tv("Quick actions",20,NAVY); quick.setTypeface(null,1); quick.setPadding(0,24,0,6); content.addView(quick);
        LinearLayout q=new LinearLayout(this);
        String[] qs={"Transfer","Deposit","Cards","Notifications"};
        for(String s:qs){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->{if(s.equals("Transfer"))transfers();else if(s.equals("Cards"))cards();else if(s.equals("Notifications"))notifications();else Toast.makeText(this,"Demo deposit screen.",Toast.LENGTH_SHORT).show();});q.addView(b,new LinearLayout.LayoutParams(0,58,1));} content.addView(q);
        section("Accounts");
        account("Everyday Checking","•••• 4821","$18,420.15");
        account("Growth Savings","•••• 9054","$6,260.27");
        section("Recent activity");
        for(int i=0;i<3;i++) transaction(tx[i]);
    }
    void section(String s){TextView t=tv(s,20,NAVY);t.setTypeface(null,1);t.setPadding(0,22,0,4);content.addView(t);}
    void account(String n,String id,String amt){
        LinearLayout x=box(); LinearLayout row=new LinearLayout(this); TextView left=tv(n+"\n"+id,16,NAVY); TextView right=tv(amt,17,NAVY); right.setGravity(Gravity.RIGHT); row.addView(left,new LinearLayout.LayoutParams(0,62,1));row.addView(right,new LinearLayout.LayoutParams(0,62,1));x.addView(row);
        x.setOnClickListener(v->accountDetails(n,id,amt)); content.addView(x);
    }
    void transaction(String s){LinearLayout x=box();x.setPadding(18,12,18,12);x.addView(tv(s,14,NAVY));content.addView(x);}
    void accounts(){
        base(true); heading("Accounts","View balances and account details.");
        account("Everyday Checking","•••• 4821","$18,420.15");
        account("Growth Savings","•••• 9054","$6,260.27");
        section("Account security"); content.addView(tv("Demo accounts contain fictional balances. Real banking connections are not enabled.",14,Color.DKGRAY));
    }
    void accountDetails(String n,String id,String amt){
        base(true); heading("Account Details",n);
        LinearLayout x=box(); x.addView(tv("AVAILABLE BALANCE",12,Color.GRAY));TextView a=tv(amt,34,NAVY);a.setTypeface(null,1);x.addView(a);
        x.addView(tv("Account number  "+id+"\nRouting number  DEMO-0000\nAccount type  "+n,14,Color.DKGRAY));content.addView(x);
        section("Transactions");for(String s:tx)transaction(s);
    }
    void transfers(){
        base(true); heading("Transfers","Create a fictional demo transfer.");
        LinearLayout x=box();
        EditText to=new EditText(this);to.setHint("Recipient name");x.addView(to);
        EditText amount=new EditText(this);amount.setHint("Amount");amount.setInputType(2|8192);x.addView(amount);
        EditText memo=new EditText(this);memo.setHint("Memo (optional)");x.addView(memo);
        Button send=btn("Review Demo Transfer",v->new AlertDialog.Builder(this).setTitle("Demo transfer").setMessage("No money will move. This is a fictional preview for "+to.getText()+" of $"+amount.getText()+".").setPositiveButton("OK",null).show());
        x.addView(send);content.addView(x);
        section("Scheduled / recent transfers");transaction("Demo Transfer • Sep 21, 2026     +$450.00");
    }
    void cards(){
        base(true); heading("Cards","Fictional cards for the M.Tbank demo.");
        LinearLayout c=box();c.setBackground(bg(NAVY,24));TextView n=tv("M.Tbank",22,Color.WHITE);n.setTypeface(null,1);c.addView(n);c.addView(tv("••••  ••••  ••••  4821",22,Color.WHITE));c.addView(tv("ALEX MORGAN                       09/29",12,Color.WHITE));content.addView(c);
        section("Card controls");content.addView(tv("Card status: Active (demo)\nFreeze card • Replace card • Spending limits",15,Color.DKGRAY));
    }
    void profile(){
        base(true); heading("Profile","Demo customer settings.");
        LinearLayout x=box();x.addView(tv("Alex Morgan",22,NAVY));x.addView(tv("demo@mtbank.example\nDemo customer ID: MT-DEMO-4821",14,Color.DKGRAY));content.addView(x);
        section("Security");content.addView(tv("Password • Biometric demo • Notification preferences",15,Color.DKGRAY));
        Button n=new Button(this);n.setText("Open Notifications");n.setAllCaps(false);n.setOnClickListener(v->notifications());content.addView(n);
    }
    void notifications(){
        base(true); heading("Notifications","Demo alerts and account messages.");
        transaction("New demo deposit received  •  Sep 26");
        transaction("Card purchase at Harbor Coffee  •  Sep 27");
        transaction("Security reminder: demo mode is active");
    }
}
